//
//  inputDetailViewController.swift
//  FawcettKeithCalorieApp
//
//  Created by Keith Fawcett on 9/7/16.
//  Copyright © 2016 Keith Fawcett. All rights reserved.
//

import UIKit
import CoreData

class InputDetailViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
  
  @IBOutlet weak var calories: UILabel!
  @IBOutlet weak var fats: UILabel!
  @IBOutlet weak var protien: UILabel!
  @IBOutlet weak var carbohydrates: UILabel!
  @IBOutlet weak var servingSize: UILabel!
  @IBOutlet weak var servingPicker: UIPickerView!
  
  var servingPickerArray = [0.25, 0.50 , 0.75, 1.00, 1.25, 1.50 , 1.75, 2.00, 2.25, 2.50 , 2.75, 3.00, 3.25, 3.50 , 3.75, 4.00, 4.25, 4.50 , 4.75, 5.00, 5.25, 5.50 , 5.75, 6.00]
  
  
  var selectedFood:Food?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    servingPicker.delegate = self
    
    self.title = selectedFood!.name!
    calories.text = String(selectedFood!.calories!)
    fats.text = String(selectedFood!.fat!)
    protien.text = String(selectedFood!.protein!)
    carbohydrates.text = String(selectedFood!.carbohydrates!)
    servingSize.text = String(selectedFood!.servingSize!) + " " + String(selectedFood!.servingUnit!)
    
    // Do any additional setup after loading the view.
    
    
    //      calories.text = String(selectedFood!.calories)
    //      fats.text = String(selectedFood!.fat)
    
    
  }
  
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }
  
  func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
    return String(servingPickerArray[row])
  }
  
  func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    return servingPickerArray.count
  }
  
  func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
    return 1
  }
  
  

  @IBAction func addButton(sender: AnyObject) {
  
    let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let context: NSManagedObjectContext = appDel.managedObjectContext
    
    let dailyItems = NSEntityDescription.insertNewObjectForEntityForName("DailyItems", inManagedObjectContext: context)
    dailyItems.setValue(Double((selectedFood?.calories)!) * Double(servingPickerArray[servingPicker.selectedRowInComponent(0)]), forKey: "calories")
    
    dailyItems.setValue(Double((selectedFood?.carbohydrates)!) * Double(servingPickerArray[servingPicker.selectedRowInComponent(0)]), forKey: "carbs")
    
    dailyItems.setValue(Double((selectedFood?.protein)!) * Double(servingPickerArray[servingPicker.selectedRowInComponent(0)]), forKey: "protein")
    
    dailyItems.setValue(Double((selectedFood?.fat)!) * Double(servingPickerArray[servingPicker.selectedRowInComponent(0)]), forKey: "fats")
    
    
    do{
      try context.save()
      
    }catch{
      print("There was an error saving data.")
    }
    
    navigationController?.popViewControllerAnimated(true)
    
    
  }
}










/*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
 // Get the new view controller using segue.destinationViewController.
 // Pass the selected object to the new view controller.
 }
 */


