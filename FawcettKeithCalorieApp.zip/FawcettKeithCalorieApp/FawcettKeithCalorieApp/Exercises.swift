//
//  Exercises.swift
//  FawcettKeithCalorieApp
//
//  Created by Keith Fawcett on 9/9/16.
//  Copyright © 2016 Keith Fawcett. All rights reserved.
//

import UIKit
import Foundation


//create exercises class
class Exercises: NSObject {
  
  let title: String
  let image: UIImage
  let desc : String
  
  init(title : String, image : UIImage, description: String) {
    self.title = title
    self.image = image
    self.desc = description
  }

}
