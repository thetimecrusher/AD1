//
//  PhotoViewController.swift
//  FawcettKeithCalorieApp
//
//  Created by Keith Fawcett on 9/7/16.
//  Copyright © 2016 Keith Fawcett. All rights reserved.
//

import UIKit
import CoreData

class PhotoViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource {
  
var currentWeight: AnyObject? = 0

  @IBOutlet weak var photoTableView: UITableView!
  @IBAction func addPhotoButton(sender: AnyObject) {
    
    let picker = UIImagePickerController()
    
    picker.delegate = self
    picker.sourceType = .Camera
    
    presentViewController(picker, animated: true, completion: nil)
    
  
  }
  

  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    

  
  
    self.photoTableView.dataSource = self
    self.photoTableView.delegate = self
    loadData()
    getData()
  }
  
  func loadData(){
    let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let context: NSManagedObjectContext = appDel.managedObjectContext
    
    do{
      
      let request = NSFetchRequest(entityName: "WeightInfo")
      let results = try context.executeFetchRequest(request)
      
      
      
      var items = results as! [NSManagedObject]
      
      if results.count > 0 {
        currentWeight = 0
        
        for i in 1...results.count{
          
          if (currentWeight! as! NSNumber == 0){
            currentWeight = items[results.count-i].valueForKey("currentWeights")
          }
        }
      }
    }catch{
      print("There was an error saving data.")
    }
  }
  
  
  
  func getData(){
    photoArray = []
    do{
      let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
      let context: NSManagedObjectContext = appDel.managedObjectContext
      
      let request = NSFetchRequest(entityName: "ImageData")
      let results = try context.executeFetchRequest(request)
      
      if results.count > 0 {
        for items in results as! [NSManagedObject]{
          let imageDay = items.valueForKey("day")
          let imageMonth = items.valueForKey("month")
          let imageYear = items.valueForKey("year")
          let imageBinary = items.valueForKey("images")
          let imageWeight = items.valueForKey("weights")
          
          let finalImage = UIImage(data:imageBinary as! NSData)
          
          let picInfo = Photos(date: "\(imageMonth!)"+"/"+"\(imageDay!)"+"/"+"\(imageYear!)", weight: String(imageWeight!), image: finalImage!)
          
          
          
          photoArray.insert(picInfo, atIndex: 0)
          
        }
        
        
      }
      
      
    }catch{
      print("There was an error saving data.")
    }
  }
  
  
  
  
  func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
    let capturedImage = info[UIImagePickerControllerOriginalImage] as? UIImage
    dismissViewControllerAnimated(true, completion: nil)
    
    loadData()
    
    let date = NSDate()
    let calendar = NSCalendar.currentCalendar()
    let components = calendar.components([.Day , .Month , .Year], fromDate: date)
    
    let year =  components.year
    let month = components.month
    let day = components.day
    
    let imgData = UIImageJPEGRepresentation(capturedImage!, 1)
    
    let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let context: NSManagedObjectContext = appDel.managedObjectContext
    
    let ImageData = NSEntityDescription.insertNewObjectForEntityForName("ImageData", inManagedObjectContext: context)
    ImageData.setValue(imgData, forKey: "images")
    ImageData.setValue(year, forKey: "year")
    ImageData.setValue(month, forKey: "month")
    ImageData.setValue(day, forKey: "day")
    ImageData.setValue(currentWeight, forKey: "weights")
    
    
    
    do{
      try context.save()
      
    }catch{
      print("There was an error saving data.")
    }
    
    
    getData()
    
    
    
    photoTableView.reloadData()
  }
  
  
  var photoArray: [Photos] = []

  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }
  
  
  
  func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return photoArray.count
  }
  
  func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
    let cell = tableView.dequeueReusableCellWithIdentifier("photoCell")!
    
    let photoDate = photoArray[indexPath.row].date
    let photoWeight = photoArray[indexPath.row].weight
    let photoImage = photoArray[indexPath.row].image
    
    
    let dateLabel = cell.viewWithTag(1) as! UILabel
    dateLabel.text = "Date: \(photoDate)"
    
    let weightLabel = cell.viewWithTag(2) as! UILabel
    weightLabel.text = "Weight: \(photoWeight)"
    
    let weightImage = cell.viewWithTag(3) as! UIImageView
    weightImage.image = photoImage
    
    return cell
    
    
  }

  
  
}
