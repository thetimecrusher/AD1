//
//  GraphViewController.swift
//  FawcettKeithCalorieApp
//
//  Created by Keith Fawcett on 9/7/16.
//  Copyright © 2016 Keith Fawcett. All rights reserved.
//

import UIKit
import CoreData
import JBChart

class GraphViewController: UIViewController, JBLineChartViewDelegate, JBLineChartViewDataSource,UIPickerViewDelegate, UIPickerViewDataSource {
  
  var goal: AnyObject? = 0
  var current:AnyObject? = 0
  
  @IBOutlet weak var goalLabel: UILabel!
  @IBOutlet weak var currentLabel: UILabel!
  
  @IBAction func goalChange(sender: AnyObject) {
    weightPicker.hidden = false
    apply.hidden = false
    changeWhat = "goal"
    
  }
  @IBAction func currentChange(sender: AnyObject) {
    weightPicker.hidden = false
    apply.hidden = false
    changeWhat = "current"
  }
  @IBOutlet weak var weightPicker: UIPickerView!
  @IBOutlet weak var apply: UIButton!
  
  @IBAction func applyButton(sender: AnyObject) {
    let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let context: NSManagedObjectContext = appDel.managedObjectContext
    
    let weightInfo = NSEntityDescription.insertNewObjectForEntityForName("WeightInfo", inManagedObjectContext: context)

    
    
    
    if (changeWhat == "goal"){
      goalLabel.text = String(pickerArray[weightPicker.selectedRowInComponent(0)])
      weightInfo.setValue(pickerArray[weightPicker.selectedRowInComponent(0)], forKey: "goalWeight")
      do{
        try context.save()
        
      }catch{
        print("There was an error saving data.")
      }
    }else {
      currentLabel.text = String(pickerArray[weightPicker.selectedRowInComponent(0)])
      weightInfo.setValue(pickerArray[weightPicker.selectedRowInComponent(0)], forKey: "currentWeights")
      do{
        try context.save()
        
      }catch{
        print("There was an error saving data.")
      }
    }
    weightPicker.hidden = true
    apply.hidden = true
    
    
    
    
    do{
      
      let request = NSFetchRequest(entityName: "WeightInfo")
      let results = try context.executeFetchRequest(request)
      
      
      
      var items = results as! [NSManagedObject]
      
      if results.count > 0 {
        goal = 0
        current = 0
          
          for i in 1...results.count{
          
          if (goal! as! NSNumber == 0){
             goal = items[results.count-i].valueForKey("goalWeight")
          }
          
          if (current! as! NSNumber == 0){
           current = items[results.count-i].valueForKey("currentWeights")
          }
          }
        }

        
      
      print(goal!)
      print(current!)
      
    }catch{
      print("There was an error saving data.")
    }
    
    
    
    
    
  }

  
  

  
  @IBOutlet weak var lineChart: JBLineChartView!
  @IBOutlet weak var infoLabel: UILabel!
  
  var date: [String] = []
  var weights: [Int] = []
  var calories: [Int] = []
  
  var currentWeight: Double = 0.0
  var goalWeight: Double = 0.0
  
  var changeWhat: String = ""
  
  var pickerArray = [90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,1661,67,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200]
  

  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    getInfo()
    //view.backgroundColor = UIColor.darkGrayColor()
    weightPicker.delegate = self
    hideChart()
    weightPicker.hidden = true
    apply.hidden = true
    
    
    
    
    //line chart setup
    lineChart.backgroundColor = UIColor.darkGrayColor()
    lineChart.delegate = self
    lineChart.dataSource = self
    
    //to-do add footer and header
    let footerView = UIView(frame: CGRectMake(0,0, lineChart.frame.width, 16))
    
    
    let footer1 = UILabel(frame: CGRectMake(0,0, lineChart.frame.width/2, 16))
    footer1.textColor = UIColor.whiteColor()
    footer1.text = "\(date[0])"
    
    let footer2 = UILabel(frame: CGRectMake(lineChart.frame.width/2,0, lineChart.frame.width/2, 16))
    footer2.textColor = UIColor.whiteColor()
    footer2.text = "\(date[date.count - 1])"
    footer2.textAlignment = NSTextAlignment.Right
    
    footerView.addSubview(footer1)
    footerView.addSubview(footer2)
    
    
    let header = UILabel(frame: CGRectMake(0,0, lineChart.frame.width, 50))
    header.textColor = UIColor.whiteColor()
    header.font = UIFont.systemFontOfSize(24)
    header.text = "Body weight vs. Calorie Intake"
    header.textAlignment = NSTextAlignment.Center
    
    lineChart.footerView = footerView
    lineChart.headerView = header
    
    
    lineChart.reloadData()
    
    lineChart.setState(.Collapsed, animated: true)
    
  }
  

  func getInfo(){
    let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let context: NSManagedObjectContext = appDel.managedObjectContext
    
    do{
      
      let request = NSFetchRequest(entityName: "WeightInfo")
      let results = try context.executeFetchRequest(request)
      
      
      
      var items = results as! [NSManagedObject]
      
      if results.count > 0 {
        goal = 0
        current = 0
        
        for i in 1...results.count{
          
          if (goal! as! NSNumber == 0){
            goal = items[results.count-i].valueForKey("goalWeight")
          }
          
          if (current! as! NSNumber == 0){
            current = items[results.count-i].valueForKey("currentWeights")
          }
        }
      }
      goalLabel.text = String(goal!)
      currentLabel.text = String(current!)
      
      
      print(goal!)
      print(current!)
      
    }catch{
      print("There was an error saving data.")
    }
    
    do{
      let request = NSFetchRequest(entityName: "ForeverItems")
      let results = try context.executeFetchRequest(request)
      
      date = []
      weights = []
      calories = []
      
      
      if results.count > 0 {
        for items in results as! [NSManagedObject]{
          let graphDay = items.valueForKey("day")
          let graphMonth = items.valueForKey("month")
          let graphYear = items.valueForKey("year")
          let graphWeight = items.valueForKey("currentWeights")
          let graphCalories = items.valueForKey("endCalories")
          
          
          date.append("\(graphMonth!)"+"/"+"\(graphDay!)"+"/"+"\(graphYear!)")
          weights.append(Int(graphWeight! as! NSNumber))
          calories.append(Int(graphCalories! as! NSNumber))
          
        }
        
        
      }
      if date.count > 1{
      date.removeAtIndex(0)
      weights.removeAtIndex(0)
      calories.removeAtIndex(0)
      }
      
      
      
    }catch{
      print("There was an error saving data.")
    }
  }

  
  override func viewDidAppear(animated: Bool) {
    super.viewDidAppear(animated)
    
    getInfo()
    lineChart.reloadData()
    
    NSTimer.scheduledTimerWithTimeInterval(0.5, target: self, selector: (#selector(GraphViewController.showChart)), userInfo: nil, repeats: false)
  }
  
  override func viewDidDisappear(animated: Bool) {
    super.viewDidDisappear(animated)
    hideChart()
  }
  
  func hideChart(){
    lineChart.setState(.Collapsed, animated: true)
  }
  
  func showChart(){
    lineChart.setState(.Expanded, animated: true)
  }
  
 
  
  
  //MARK: JBlineChartView
  
  func numberOfLinesInLineChartView(lineChartView: JBLineChartView!) -> UInt {
    return 2
  }
  
  func lineChartView(lineChartView: JBLineChartView!, numberOfVerticalValuesAtLineIndex lineIndex: UInt) -> UInt {
    if (lineIndex == 0){
      return UInt(weights.count)
    }else if (lineIndex == 1){
      return UInt(calories.count)
    }
    return 0
  }
  
  func lineChartView(lineChartView: JBLineChartView!, verticalValueForHorizontalIndex horizontalIndex: UInt, atLineIndex lineIndex: UInt) -> CGFloat {
    if (lineIndex == 0){
      return CGFloat(weights[Int(horizontalIndex)])
    } else if (lineIndex == 1){
      return CGFloat(calories[Int(horizontalIndex)]/20)
    }
    return 0
  }
  
  func lineChartView(lineChartView: JBLineChartView!, colorForLineAtLineIndex lineIndex: UInt) -> UIColor! {
    if (lineIndex == 0){
      return UIColor.lightGrayColor()
    } else if (lineIndex == 1){
      return UIColor.whiteColor()
    }
    return UIColor.lightGrayColor()
  }
  
  
  func lineChartView(lineChartView: JBLineChartView!, colorForDotAtHorizontalIndex horizontalIndex: UInt, atLineIndex lineIndex: UInt) -> UIColor! {
    return UIColor.lightGrayColor()
  }
  
  func lineChartView(lineChartView: JBLineChartView!, smoothLineAtLineIndex lineIndex: UInt) -> Bool {
    return false
  }
  
  func lineChartView(lineChartView: JBLineChartView!, didSelectLineAtIndex lineIndex: UInt, horizontalIndex: UInt) {
    if (lineIndex == 0){
      let data = weights[Int(horizontalIndex)]
      let key = date[Int(horizontalIndex)]
      infoLabel.text = "Weight on \(key) was \(data)"
    }else if (lineIndex == 1){
      let data = calories[Int(horizontalIndex)]
      let key = date[Int(horizontalIndex)]
      infoLabel.text = "Calories on \(key) was \(data)"
    }
  }
  
  func didDeselectLineInLineChartView(lineChartView: JBLineChartView!) {
    infoLabel.text = ""
  }
  
  
  
  //MARK: Picker
  
  func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
    return String(pickerArray[row])
  }
  
  func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    return pickerArray.count
  }
  
  func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
    return 1
  }
  
  
  
  
}




























