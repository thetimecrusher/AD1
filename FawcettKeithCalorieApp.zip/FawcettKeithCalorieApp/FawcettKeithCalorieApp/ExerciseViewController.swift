//
//  ExerciseViewController.swift
//  FawcettKeithCalorieApp
//
//  Created by Keith Fawcett on 9/7/16.
//  Copyright © 2016 Keith Fawcett. All rights reserved.
//

import UIKit

class ExerciseViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
  @IBOutlet weak var tableView: UITableView!
  
  var infoArray : [Exercises] = []
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    
    self.tableView.dataSource = self
    self.tableView.delegate = self
    
    
    
  
  let highPlankImage = UIImage(named: "1 plank.jpg")
  let squatImage = UIImage(named: "2 squat.jpg")
  let pushUpImage = UIImage(named: "3 pushup.jpg")
  let lungeImage = UIImage(named: "4 lunge.jpg")
  let burpeeImage = UIImage(named: "5 burpee.jpg")
  
  
  
  
    let highPlank = Exercises(title: "1. The High Plank", image: highPlankImage!, description: "Start on your hands and knees on the ground. Your hands and knees should be shoulder-width apart, hands under shoulders and knees under hips. Lift your knees off the ground and step your feet back, bringing your body to full extension. You want to create one long line that connects your shoulders, hips, and ankles. Reach back through your heels and forward through the crown of your head. To keep your neck and spine in a neutral position, try aiming your chin about six inches in front of your body. Keeping a tight core is key here. Tighten your quads, engage your abdominals, and push through your palms. Keep those hips lifted and don’t forget to breathe! Moving your feet closer together will make this exercise more challenging.")
  let squat = Exercises(title: "2. The Bodyweight Squat", image: squatImage!, description: "Start standing with your feet slightly wider than hip-width apart, feet turned out about 5-15 degrees. Hinge your hips back toward a wall (real or imaginary) behind you, and bend your knees to lower into a squat. Keep the weight in your heels and your chest upright. Keep your knees inline with your feet (don’t let them buckle in). Go as low as you can, then push through your heels to return to standing.")
  let pushUp = Exercises(title: "3. The Push-Up", image: pushUpImage!, description: "Start in a high plank position and place your palms under your shoulders or slightly wider. Keep your fingers pointing directly forward. Keep your core tight and bend elbows to lower torso toward the floor. Don’t let your hips drop down before your chest lowers. Go as low as you can, then push through your palms to straighten your arms.")
  let lunge = Exercises(title: "4. The Reverse Lunge", image: lungeImage!, description: "Start in a standing position with your feet about shoulder-width apart. Inhale as you step backwards with your right foot. Land on the ball of your right foot and keep your heel off the ground. Now bend your knees creating two 90-degree angles with your legs. Your left shin should be perpendicular to the floor and your left knee is stacked above your left ankle. Aim to have your back knee hovering about 3-6 inches off the ground. Get low! You want to have your shoulders directly above your hips and your chest is upright.  Push off with your back foot and press through your front heel to return to standing.")
  let burpee = Exercises(title: "5. The Burpee", image: burpeeImage!, description: "Start standing with your feet hip-distance apart. Then bring your palms to the floor. Jump your feet back so that you are in high plank, keeping your core tight and your hips lifted. Bend your elbows and do a push-up, returning to high plank. (Some variations of the burpee skip this step or do it slightly differently. Do what works best for you!) Now jump your feet to the outsides of your hands and explode up. Reach your arms overhead as you jump as high as you can.")
  
  infoArray = [highPlank, squat, pushUp, lunge, burpee]
  
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }
  
  
  
  func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return infoArray.count
  }
  
  func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
    
    let cell = tableView.dequeueReusableCellWithIdentifier("exercisesCell")!
    
    let exerciseTitle = infoArray[indexPath.row].title
    let exerciseImage = infoArray[indexPath.row].image
    let exerciseDesc = infoArray[indexPath.row].desc
    
    let exerciseTitleLabel = cell.viewWithTag(1) as! UILabel
    exerciseTitleLabel.text = exerciseTitle
    
    let exerciseImageLabel = cell.viewWithTag(2) as! UIImageView
    exerciseImageLabel.image = exerciseImage
    
    let exerciseDescLabel = cell.viewWithTag(3) as! UITextView
    exerciseDescLabel.text = exerciseDesc
    
    return cell
    
    
  }
  
  
  
  
}

















