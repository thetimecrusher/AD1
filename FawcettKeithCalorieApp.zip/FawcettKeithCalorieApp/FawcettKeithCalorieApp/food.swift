//
//  food.swift
//  FawcettKeithCalorieApp
//
//  Created by Keith Fawcett on 9/7/16.
//  Copyright © 2016 Keith Fawcett. All rights reserved.
//

import UIKit

class Food: NSObject {
  
  var name:String?
  var calories:Int?
  var fat:Int?
  var protein:Int?
  var carbohydrates:Int?
  var servingSize:Int?
  var servingUnit: String?


}
