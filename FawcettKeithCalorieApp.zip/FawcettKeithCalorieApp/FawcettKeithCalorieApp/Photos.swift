//
//  Photos.swift
//  FawcettKeithCalorieApp
//
//  Created by Keith Fawcett on 9/19/16.
//  Copyright © 2016 Keith Fawcett. All rights reserved.
//

import UIKit
import Foundation

//create photos class
class Photos: NSObject {
  
  let date: String
  let weight : String
  let image: UIImage
  
  
  init(date : String, weight: String, image : UIImage) {
    self.date = date
    self.weight = weight
    self.image = image
    
  }
  
}
