//
//  ViewController.swift
//  FawcettKeithCalorieApp
//
//  Created by Keith Fawcett on 9/6/16.
//  Copyright © 2016 Keith Fawcett. All rights reserved.
//

import UIKit

class DiaryViewController: UIViewController {

  
  @IBOutlet weak var calorieImageView: UIImageView!
  @IBOutlet weak var fatImageView: UIImageView!
  @IBOutlet weak var carbsImageView: UIImageView!
  @IBOutlet weak var proteinImageView: UIImageView!
  @IBOutlet weak var exerciseImageView: UIImageView!
  
  @IBOutlet weak var caloriesLabel: UILabel!
  @IBOutlet weak var fatsLabel: UILabel!
  @IBOutlet weak var carbsLabel: UILabel!
  @IBOutlet weak var proteinLabel: UILabel!
  @IBOutlet weak var exerciseLabel: UILabel!
  
  
  var caloriesEaten: Double = 3250
  var fatEaten:Double = 37
  var carbsEaten: Double = 165
  var proteinEaten:Double = 115
  var exerciseDone:Double = 30
  
  var caloriesNeeded: Double = 2250
  var fatNeeded: Double = 50
  var carbsNeeded: Double = 225
  var proteinNeeded: Double = 225
  var exerciseNeeded: Double = 60
  
  
  
  
  @IBOutlet weak var sliderOutlet: UISlider!
  

  
  override func viewDidLoad() {
    //UITabBar.appearance().barTintColor = color
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    if Int(round((caloriesEaten/caloriesNeeded)*100)) > 103{
      calorieImageView.image = UIImage(named: "circle103+.png")
    }else{calorieImageView.image = UIImage(named: "circle" + String(Int(round((caloriesEaten/caloriesNeeded)*100))) + ".png")}
    
    if Int(round((fatEaten/fatNeeded)*100)) > 103{
      fatImageView.image = UIImage(named: "circle103+.png")
    }else{fatImageView.image = UIImage(named: "circle" + String(Int(round((fatEaten/fatNeeded)*100))) + ".png")}
    
      if Int(round((carbsEaten/carbsNeeded)*100)) > 103{
        carbsImageView.image = UIImage(named: "circle103+.png")
    }else{carbsImageView.image = UIImage(named: "circle" + String(Int(round((carbsEaten/carbsNeeded)*100))) + ".png")}
    
        if Int(round((proteinEaten/proteinNeeded)*100)) > 103{
          proteinImageView.image = UIImage(named: "circle103+.png")
    }else{proteinImageView.image = UIImage(named: "circle" + String(Int(round((proteinEaten/proteinNeeded)*100))) + ".png")}
    
    if Int(round((exerciseDone/exerciseNeeded)*100)) > 100{
      exerciseImageView.image = UIImage(named: "bar100.png")
    }else{exerciseImageView.image = UIImage(named: "bar" + String(Int(round((exerciseDone/exerciseNeeded)*100))) + ".png")}
    
    caloriesLabel.text = String(Int(caloriesEaten)) + "/" + String(Int(caloriesNeeded))
    fatsLabel.text = String(Int(fatEaten)) + "/" + String(Int(fatNeeded))
    carbsLabel.text = String(Int(carbsEaten)) + "/" + String(Int(carbsNeeded))
    proteinLabel.text = String(Int(proteinEaten)) + "/" + String(Int(proteinNeeded))
    exerciseLabel.text = "Excercise " + String(Int(exerciseDone)) + "/" + String(Int(exerciseNeeded)) + "min"
    
    
    
  }

  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }


}

