//
//  ViewController.swift
//  FawcettKeithCalorieApp
//
//  Created by Keith Fawcett on 9/6/16.
//  Copyright © 2016 Keith Fawcett. All rights reserved.
//

import UIKit
import CoreData

class DiaryViewController: UIViewController {
  
  //create outlets for all images and labels
  @IBOutlet weak var calorieImageView: UIImageView!
  @IBOutlet weak var fatImageView: UIImageView!
  @IBOutlet weak var carbsImageView: UIImageView!
  @IBOutlet weak var proteinImageView: UIImageView!
  @IBOutlet weak var exerciseImageView: UIImageView!
  
  @IBOutlet weak var caloriesLabel: UILabel!
  @IBOutlet weak var fatsLabel: UILabel!
  @IBOutlet weak var carbsLabel: UILabel!
  @IBOutlet weak var proteinLabel: UILabel!
  @IBOutlet weak var exerciseLabel: UILabel!
  
  
  
  //create variables for the needed items
  var caloriesNeeded: Double = 2250
  var fatNeeded: Double = 50
  var carbsNeeded: Double = 225
  var proteinNeeded: Double = 225
  var exerciseNeeded: Double = 60
  
  var endCalories:Double = 0
  
  var currentWeight: AnyObject? = 0
  var goalWeight: AnyObject? = 0
  
  
  
  override func viewDidAppear(animated: Bool) {
    super.viewDidAppear(animated)
    
    loadData()
    getFoodNeeds()
    
    
    //get the current date
    let date = NSDate()
    let calendar = NSCalendar.currentCalendar()
    let components = calendar.components([.Day , .Month , .Year], fromDate: date)
    
    let year =  components.year
    let month = components.month
    let day = components.day
    
    
    
    //compair current date with previous date and save the current date if needed
    let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let context: NSManagedObjectContext = appDel.managedObjectContext
    
    do{
      
      let request = NSFetchRequest(entityName: "ForeverItems")
      let results = try context.executeFetchRequest(request)
      
      
      var lastDate = results as! [NSManagedObject]
      
      
      if lastDate.count > 0 {
        let lastDay = lastDate[lastDate.count-1].valueForKey("day")
        let lastMonth = lastDate[lastDate.count-1].valueForKey("month")
        let lastYear = lastDate[lastDate.count-1].valueForKey("year")

        
        
        if ("\(lastDay!) + \(lastMonth!) + \(lastYear!)" != "\(day) + \(month) + \(year)"){
          
          do{
            let request = NSFetchRequest(entityName: "DailyItems")
            let results = try context.executeFetchRequest(request)
            
            
            
            for items in results as! [NSManagedObject]{
              let calories = items.valueForKey("calories")
              endCalories = endCalories + Double(calories! as! NSNumber)
              
            }}catch{
              print("There was an error saving data.")
          }
          print(endCalories)
          
          //save date weight and calories
          let ForeverItems = NSEntityDescription.insertNewObjectForEntityForName("ForeverItems", inManagedObjectContext: context)
          ForeverItems.setValue(endCalories, forKey: "endCalories")
          ForeverItems.setValue(day, forKey: "day")
          ForeverItems.setValue(month, forKey: "month")
          ForeverItems.setValue(year, forKey: "year")
          ForeverItems.setValue(currentWeight, forKey: "currentWeights")
          
          do{
            try context.save()
            
          }catch{
            print("There was an error saving data.")
          }
          
          
          //delete everything out of DailyItems
          let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
          let context: NSManagedObjectContext = appDel.managedObjectContext
          let request = NSFetchRequest(entityName: "DailyItems")
          request.returnsObjectsAsFaults = false
          
          
          do{
            
            let incidents = try context.executeFetchRequest(request)
            
            if incidents.count > 0 {
              for result: AnyObject in incidents{
                context.deleteObject(result as! NSManagedObject)
                print("has been deleted")
              }
              do{
                try context.save()
              }catch{
                print("There was an error deleting data.")
              }
            }
          }
          
        }
        
      }else{
        
        //if first time running app save the current date
        let firstDate = NSEntityDescription.insertNewObjectForEntityForName("ForeverItems", inManagedObjectContext: context)
        firstDate.setValue(day, forKey: "day")
        firstDate.setValue(month, forKey: "month")
        firstDate.setValue(year, forKey: "year")
        
        
        do{
          try context.save()
          
        }catch{
          print("There was an error saving data.")
        }
      }
      
      
    }catch{
      print("Failed")
    }
    
    
    var caloriesEaten: Double = 0
    var fatEaten:Double = 0
    var carbsEaten: Double = 0
    var proteinEaten:Double = 0
    var exerciseDone:Double = 0
    
    
    do{
      
      //fetch calories exercise and macros from core data
      let request = NSFetchRequest(entityName: "DailyItems")
      let results = try context.executeFetchRequest(request)
      
      
      
      if results.count > 0 {
        
        var exerciseTotal: Double = 0
        var caloriesTotal: Double = 0
        var carbsTotal: Double = 0
        var proteinTotal: Double = 0
        var fatsTotal: Double = 0
        
        
        
        
        for items in results as! [NSManagedObject]{
          let time = items.valueForKey("exerciseTime")
          exerciseTotal = exerciseTotal + Double(time! as! NSNumber)
          
          let calories = items.valueForKey("calories")
          caloriesTotal = caloriesTotal + Double(calories! as! NSNumber)
          
          let carbs = items.valueForKey("carbs")
          carbsTotal = carbsTotal + Double(carbs! as! NSNumber)
          
          let protein = items.valueForKey("protein")
          proteinTotal = proteinTotal + Double(protein! as! NSNumber)
          
          let fats = items.valueForKey("fats")
          fatsTotal = fatsTotal + Double(fats! as! NSNumber)
        }
        
        caloriesEaten = caloriesTotal
        fatEaten = fatsTotal
        carbsEaten = carbsTotal
        proteinEaten = proteinTotal
        exerciseDone = exerciseTotal
        
        
        
        
      }
      
      
    }catch{
      print("There was an error saving data.")
    }
    if caloriesNeeded == 0 {
      caloriesNeeded = 2250
      fatNeeded = 50
      carbsNeeded = 225
      proteinNeeded = 225
      exerciseNeeded = 60
    }
    
    //display current calories exercise and macros
    
    if Int(round((caloriesEaten/caloriesNeeded)*100)) > 103{
      calorieImageView.image = UIImage(named: "circle103+.png")
    }else{calorieImageView.image = UIImage(named: "circle" + String(Int(round((caloriesEaten/caloriesNeeded)*100))) + ".png")}
    
    if Int(round((fatEaten/fatNeeded)*100)) > 103{
      fatImageView.image = UIImage(named: "circle103+.png")
    }else{fatImageView.image = UIImage(named: "circle" + String(Int(round((fatEaten/fatNeeded)*100))) + ".png")}
    
    if Int(round((carbsEaten/carbsNeeded)*100)) > 103{
      carbsImageView.image = UIImage(named: "circle103+.png")
    }else{carbsImageView.image = UIImage(named: "circle" + String(Int(round((carbsEaten/carbsNeeded)*100))) + ".png")}
    
    if Int(round((proteinEaten/proteinNeeded)*100)) > 103{
      proteinImageView.image = UIImage(named: "circle103+.png")
    }else{proteinImageView.image = UIImage(named: "circle" + String(Int(round((proteinEaten/proteinNeeded)*100))) + ".png")}
    
    if Int(round((exerciseDone/exerciseNeeded)*100)) > 100{
      exerciseImageView.image = UIImage(named: "bar100.png")
    }else{exerciseImageView.image = UIImage(named: "bar" + String(Int(round((exerciseDone/exerciseNeeded)*100))) + ".png")}
    
    caloriesLabel.text = String(Int(caloriesEaten)) + "/" + String(Int(caloriesNeeded))
    fatsLabel.text = String(Int(fatEaten)) + "/" + String(Int(fatNeeded))
    carbsLabel.text = String(Int(carbsEaten)) + "/" + String(Int(carbsNeeded))
    proteinLabel.text = String(Int(proteinEaten)) + "/" + String(Int(proteinNeeded))
    exerciseLabel.text = "Excercise " + String(Int(exerciseDone)) + "/" + String(Int(exerciseNeeded)) + "min"
    
  }
  
  func loadData(){
    let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let context: NSManagedObjectContext = appDel.managedObjectContext
    
    do{
      
      let request = NSFetchRequest(entityName: "WeightInfo")
      let results = try context.executeFetchRequest(request)
      
      
      
      var items = results as! [NSManagedObject]
      
      if results.count > 0 {
        currentWeight = 0
        goalWeight = 0
        
        for i in 1...results.count{
          
          if (currentWeight! as! NSNumber == 0){
            currentWeight = items[results.count-i].valueForKey("currentWeights")
          }
          if (goalWeight! as! NSNumber == 0){
            goalWeight = items[results.count-i].valueForKey("goalWeight")
          }
        }
      }
    }catch{
      print("There was an error saving data.")
    }
  }
  
  
  //calculate what user needs to eat acording to their weight and goals
  func getFoodNeeds(){
    
    if Int(goalWeight! as! NSNumber) < Int(currentWeight! as! NSNumber){
    
    caloriesNeeded = Double(currentWeight! as! NSNumber) * 12.5
    fatNeeded = (caloriesNeeded * 0.35) / 9
    carbsNeeded = (caloriesNeeded * 0.2) / 4
    proteinNeeded = (caloriesNeeded * 0.45) / 4
      
    }else if Int(goalWeight! as! NSNumber) > Int(currentWeight! as! NSNumber){
      caloriesNeeded = Double(currentWeight! as! NSNumber) * 18.5
      fatNeeded = (caloriesNeeded * 0.2) / 9
      carbsNeeded = (caloriesNeeded * 0.5) / 4
      proteinNeeded = (caloriesNeeded * 0.3) / 4
      
    }else{
      caloriesNeeded = Double(currentWeight! as! NSNumber) * 15.5
      fatNeeded = (caloriesNeeded * 0.3) / 9
      carbsNeeded = (caloriesNeeded * 0.4) / 4
      proteinNeeded = (caloriesNeeded * 0.3) / 4
    }
    
    
  }
  
  
  override func viewDidLoad() {
    
    //UITabBar.appearance().barTintColor = color
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    
  }
  
  
  
}

